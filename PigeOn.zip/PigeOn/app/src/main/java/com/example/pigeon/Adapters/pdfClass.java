package com.example.pigeon.Adapters;



    public class pdfClass {

        public String url;

        public pdfClass(){

        }

        public pdfClass(String url) {
            this.url = url;
        }

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }
    }


